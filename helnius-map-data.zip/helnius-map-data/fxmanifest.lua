fx_version 'cerulean'
game 'gta5'
this_is_a_map 'yes'
lua54 'yes'
author 'helnius' -- Discord: https://discord.gg/RGgqnsxvMv
description 'helnius interior mapdata'
version '1.0-release'

replace_level_meta 'gta5'

files {
    'gta5.meta',
    'doortuning.ymt',
    'helnius_map_door_audios_game.dat151.rel'
}

data_file 'AUDIO_GAMEDATA' 'helnius_map_door_audios_game.dat'